angular.module('app.controllers', [])
  
.controller('graphCtrl', ['$scope', '$stateParams', 
function ($scope, $stateParams) {


}])
   
.controller('flashCardsCtrl', ['$scope', '$stateParams',
function ($scope, $stateParams) {


}])
   
.controller('settingsCtrl', ['$scope', '$stateParams',
function ($scope, $stateParams) {


}])
   
.controller('menuCtrl', ['$scope', '$stateParams',
function ($scope, $stateParams) {


}])
   
.controller('loginCtrl', ['$scope', '$stateParams',
function ($scope, $stateParams) {


}])
   
.controller('signupCtrl', ['$scope', '$stateParams',
function ($scope, $stateParams) {


}])
   
.controller('quizCreatorCtrl', ['$scope', '$stateParams',
function ($scope, $stateParams) {


}])
 